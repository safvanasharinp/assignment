function display(){
    document.writeln("sorry you are troubled,re sign up please")
}